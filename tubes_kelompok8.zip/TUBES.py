import socket
import os

def handle_request(request):
    request_lines = request.split("\r\n")
    method, path, _ = request_lines[0].split(" ")
    message_body = "<html><body><h1>Tugas Besar Jaringan Komputer</h1></body></html>"

    if method == "GET":
        if path == "/":
            path = "/index.html"
        file_path = os.path.join("tubes", path[1:])

        if os.path.exists(file_path):
            response_line = "HTTP/1.1 200 OK\r\n"
            content_type = "Content-Type: text/html\r\n\r\n"
            with open(file_path, "r") as file:
                message_body = file.read()
        else:
            response_line = "HTTP/1.1 404 Not Found\r\n"
            content_type = "Content-Type: text/html\r\n\r\n"
            message_body = "<html><body><h1>404 Not Found</h1></body></html>"
    else:
        response_line = "HTTP/1.1 400 Bad Request\r\n"
        content_type = "Content-Type: text/html\r\n\r\n"
        message_body = "<html><body><h1>400 Bad Request</h1></body></html>"

    response = response_line + content_type + message_body
    return response

def tcp_server():
     #server address and port
    SERVER_HOST = "127.0.0.1" #alamat lokal
    SERVER_PORT = 80 #port yang digunakan

    socket_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)#membuat objek baru dimana AF_INET: alamat berbasis pada IPv4 dan SOCK_STREAM: socket TCP
    socket_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)#menyetel opsi socket yaitu SOLSOCKET(menentukan level opsi socket),
    #SO_REUSEADDR(menentukan opsi socket yang akan diatur), 1(menentukan nilai untuk menyetel opsi)
    socket_server.bind((SERVER_HOST, SERVER_PORT))#mengubungkan alamat IP dengan nomor port ke socket

    socket_server.listen()#server menerima koneksi

    print("Server ready to launch")

    while True: #melakukan loop
        sock_client, client_address = socket_server.accept()#menerima koneksi yang akan masuk untuk membuat koneksi TCP baru dari klien yang akan mengembalikan 
         #sock_client(Objek baru untuk mengirim dan menerima data selama terhubung) dan client_address(alamat klien) 
        request = sock_client.recv(1024).decode()#menerima respon dari server dengan menentukan jumlah maks data yang akan diterima menggunakan 
         #.decode() maka akan menerjemahkan byte ke string

        print("Request from client:", request) #mencetak "Dari Client"

        response = handle_request(request)
        sock_client.send(response.encode()) #server merespon klien

        sock_client.close()#menutup socket client

    socket_server.close()

if __name__ == "__main__":
    tcp_server()

